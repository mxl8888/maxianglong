var express = require('express');
var router = express.Router();
var mysql = require('mysql');
/* 在主页获取新闻时候的请求 */
router.get('/', function(req, res, next) {
  var newstype = reg.query.newstype;
  //建立数据连接
  var connection = mysql.createConnection({
    host:'localhost',
    port:3306,
    user:'root'
    password:'root'
    database:'baidunews'
  });
  //连接建立
  connection.connect();
  connection.query('SELECT * FROM `news` WHERE `newstype` =?',[newstype],function(err,rows,fields){
    res.json(rows);
  });
});

module.exports = router;
